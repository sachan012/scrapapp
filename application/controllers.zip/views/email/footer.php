  <tr>
    <td>
      <!--<img src="<?php /*echo assets_url('img','footer-email.png') */?>" alt="kassimBaba">-->
    </td>
  </tr>
</table>
</body></html>