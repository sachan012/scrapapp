<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sendmail extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->library('email');	
		$config = Array(
            'protocol' => 'tls',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 587,
            'smtp_user' => 'info@ubuyexpress.com',
            'smtp_pass' => 'SDe@ubuyexp@123',
            'mailtype'  => 'html',
            'charset'   => 'iso-8859-1'
          );
		$this->email->initialize($config);		
		$this->email->set_newline("\r\n");
        $this->email->from(EMAIL, 'Scrap Dealer');		
		$this->email->to('sachanprashant223@gmail.com');	
		$this->email->cc('rahulr@triazinesoft.com');
		$this->email->set_mailtype('html');
		$this->email->subject("msg check");
        $this->email->message("This is test message for check");
		if(!$this->email->send()){
		        echo $this->email->print_debugger();die;
             
		}else{
		echo "Email Snt";
		}
	}
}
